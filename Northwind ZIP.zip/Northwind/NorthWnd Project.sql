use NORTHWND

select distinct [Country] from [dbo].[Customers]

-- Total Products 

select
	count([ProductID]) as 'Products'
from	
	[dbo].[Products]


-- Total Categories

select
	count([CategoryID]) as 'Categories'
from
	[dbo].[Categories]

--- Avg Price for Product

select
	avg([UnitPrice])
from
	[dbo].[Products] 


-- Total Orders

select
	count([OrderID]) as 'Orders'
from
	[dbo].[Orders]

-- Total Customers

select
	count([CustomerID])
from
	[dbo].[Customers]

--- All Products and Revenue

with cte as
(
SELECT 
    p.[ProductName], 
    FORMAT(SUM(od.[UnitPrice] * od.[Quantity]), 'N0') AS Revenue,
	(select
		sum(od.[Quantity] * od.[UnitPrice]) 
	 from	
		[dbo].[Products] AS p
		INNER JOIN
		[dbo].[Order Details] AS od ON od.ProductID = p.ProductID) as Total_Revenue,
	count([OrderID]) as Orders_count

FROM 
    [dbo].[Products] AS p
	INNER JOIN
    [dbo].[Order Details] AS od ON od.ProductID = p.ProductID
GROUP BY
    p.[ProductName]
)
select
	*,
	(Revenue / Total_Revenue) '% Of Total Revenue'
from
	cte


--- Sales by Year and Month

select
	year([OrderDate]) as 'Year',
	month([OrderDate]) as 'Month',
	count([OrderID]) as Orders_Count
from
	[dbo].[Orders]
group by
	year([OrderDate]),
	month([OrderDate])
order by
	1,
	2
	


----  What are the top 5 best-selling products by revenue?

SELECT 
    TOP 5 p.[ProductName], 
    FORMAT(SUM(od.[UnitPrice] * od.[Quantity]), 'N0') AS Revenue
FROM 
    [dbo].[Products] AS p
INNER JOIN
    [dbo].[Order Details] AS od ON od.ProductID = p.ProductID
GROUP BY
    p.[ProductName]
ORDER BY
    SUM(od.[UnitPrice] * od.[Quantity]) DESC


---- Annual Cusomers Growth Rate

with cte as
(
select
	year([OrderDate]) as 'year',
	count(distinct [CustomerID]) as 'Customers',
	lag (count(distinct [CustomerID])) over(order by year([OrderDate])) as 'Last_Year_customers',
	count(distinct [CustomerID]) - lag (count(distinct [CustomerID])) over(order by year([OrderDate])) as 'difference'
from
	[dbo].[Orders]
group by
	year([OrderDate])
)
select
	year,
	(cast(difference as float) / cast(Last_Year_customers as float)) as 'Growtg Rate'
from	
	cte


--- Customers by Country

with cte as
(
select
	count(distinct [CustomerID]) as count_customers,
	[Country],
	(select count(distinct [CustomerID]) from [dbo].[Customers]) as total_customers
from
	[dbo].[Customers]
group by
	[Country]
)
select
	[Country],
	(cast(count_customers as float) / cast(total_customers as float)) as Customers_Rate
from	
	cte




-----  What are the top 5 customers by total purchases?

select 
	top 5 c.[CompanyName],
	SUM(od.[UnitPrice] * od.[Quantity]) AS Revenue
from
	[dbo].[Customers] as c
	inner join
	[dbo].[Orders] as o on c.CustomerID = o.CustomerID
	inner join 
	[dbo].[Order Details] as od on od.OrderID = o.OrderID
group by
	c.[CompanyName]
order by
	2 desc


-- --- What are the total sales per country?

select 
	c.Country,
	sum(od.[UnitPrice]*od.[Quantity]) as 'Total Orders'
from 
	[dbo].[Orders] as o
	inner join
	[dbo].[Order Details] as od on o.[OrderID] = od.[OrderID]
	inner join
	[dbo].[Customers] as c on c.CustomerID = o.CustomerID
group by
	c.Country
order by
	2 desc


-- -- Which employee generated the highest revenue?

select
	top 1 e.[EmployeeID],
	e.[FirstName] + ' ' + e.[LastName] as 'Employee Name',
	sum(od.[Quantity] * od.[UnitPrice]) as 'Revenue'
from 
	[dbo].[Employees] as e
	inner join
	[dbo].[Orders] as o on e.EmployeeID = o.EmployeeID
	inner join
	[dbo].[Order Details] as od on o.OrderID = od.OrderID
group by
	e.[EmployeeID],
	e.[FirstName] + ' ' + e.[LastName]
order by
	3 desc




-- -- Which employee generated the lowest revenue?

select
	top 1 e.[EmployeeID],
	e.[FirstName] + ' ' + e.[LastName] as 'Employee Name',
	sum(od.[Quantity] * od.[UnitPrice]) as 'Revenue'
from 
	[dbo].[Employees] as e
	inner join
	[dbo].[Orders] as o on e.EmployeeID = o.EmployeeID
	inner join
	[dbo].[Order Details] as od on o.OrderID = od.OrderID
group by
	e.[EmployeeID],
	e.[FirstName] + ' ' + e.[LastName]
order by
	3 asc


---  What is the average order value (AOV)?

select
	(sum([Quantity] * [UnitPrice])
	/
	count(distinct [OrderID])) as 'Average Order Value'

from 
	[dbo].[Order Details]



---List all products in stock

select 
	[ProductID],
	[ProductName],
	[UnitPrice],
	[UnitsInStock]
from
	[dbo].[Products]
where
	[UnitsInStock] >0


--- Find the total number of orders per customer

select
	c.CustomerID,
	count(o.[OrderID]) as 'orders'
from
	[dbo].[Customers] as c
	left join
	[dbo].[Orders] as o on c.CustomerID=o.CustomerID
group by
	c.CustomerID
order by
	count(o.[OrderID]) desc



---- Calculate total revenue per category

select
	c.CategoryID,
	c.CategoryName,
	sum(od.[Quantity] * od.[UnitPrice]) as 'Revenue'
from 
	[dbo].[Categories] as c
	inner join
	[dbo].[Products] as p on c.CategoryID = p.CategoryID
	inner join
	[dbo].[Order Details] as od on od.ProductID = p.ProductID
group by
	c.CategoryID,
	c.CategoryName
order by
	sum(od.[Quantity] * od.[UnitPrice]) desc

---- employees by title

select	
	[Title],
	count([EmployeeID]) employees_count
from
	[dbo].[Employees]
group by
	[Title]

--- employees country

select
	[Country],
	count([EmployeeID])
from
	[dbo].[Employees]
group by
	[Country]

--- Average Tenure


WITH cte AS (
    SELECT
        e.EmployeeID,
        e.HireDate AS hire_date,
        MAX(o.OrderDate) AS last_order_date
    FROM 
        dbo.Employees AS e
        INNER JOIN dbo.Orders AS o ON e.EmployeeID = o.EmployeeID
    GROUP BY
        e.EmployeeID,
        e.HireDate
)
SELECT 
    AVG(DATEDIFF(YEAR, hire_date, last_order_date)) AS Avg_Tenure_Years
FROM cte;


--- Sum of sales

select
	year(o.[OrderDate]) as 'Year',
	DATENAME(quarter, o.[OrderDate]) 'Quarter',
	format(sum(od.[UnitPrice] * od.[Quantity]), 'N0') as 'Sales',
	format(sum(od.[UnitPrice] * od.[Quantity]), 'N0')
	/
	(select sum(od.[UnitPrice] * od.[Quantity]) 
	from [dbo].[Orders] as o inner join [dbo].[Order Details] as od on o.OrderID = od.OrderID) as '% of Total Sales'
from
	[dbo].[Orders] as o
	inner join
	[dbo].[Order Details] as od on o.OrderID = od.OrderID
group by
	year([OrderDate]),
	DATENAME(quarter, o.[OrderDate])

--- Best employee each year

with cte as
(
Select
	year(o.[OrderDate]) as 'Year',
	e.[FirstName] + ' ' + e.[LastName] as 'Employee',
	sum(od.[UnitPrice] * od.[Quantity]) as Sales,
	DENSE_RANK() over(partition by year(o.[OrderDate]) order by sum(od.[UnitPrice] * od.[Quantity]) desc) as 'Rank'
	
from
	[dbo].[Employees] as e
	inner join
	[dbo].[Orders] as o on e.[EmployeeID] = o.[EmployeeID]
	inner join
	[dbo].[Order Details] as od on o.[OrderID] = od.[OrderID]
group by
	year(o.[OrderDate]),
	od.[UnitPrice],
	od.[Quantity],
	e.[FirstName] + ' ' + e.[LastName]
)
select *
from cte
where rank = 1


--- Average Sales by Employee

Select
	avg(od.[UnitPrice] * od.[Quantity]) as Avg_Sales
from
	[dbo].[Employees] as e
	inner join
	[dbo].[Orders] as o on e.[EmployeeID] = o.[EmployeeID]
	inner join
	[dbo].[Order Details] as od on o.[OrderID] = od.[OrderID]

--- List employees and their total orders handled


select
	e.EmployeeID,
	e.FirstName + ' ' + e.LastName as 'Full Name',
	count(o.[OrderID]) as 'orders',
	(select count([OrderID]) from [dbo].[Orders]) as 'Total_Orders',
	(cast(count(o.[OrderID]) as float) / (select count(cast([OrderID] as float)) from [dbo].[Orders])) 'Orders_%'
from 
	[dbo].[Employees] as e
	left join
	[dbo].[Orders] as o on e.EmployeeID = o.EmployeeID
group by
	e.EmployeeID,
	e.FirstName + ' ' + e.LastName
order by
	count(o.[OrderID]) desc



---  Find the top 5 customers by order value


select
	top 5 c.CustomerID,
	 c.[CompanyName],
	 sum(od.[Quantity] * od.[UnitPrice]) as 'Revenue'
from
	[dbo].[Customers] as c
	inner join
	[dbo].[Orders] as o on c.CustomerID = o.CustomerID
	inner join
	[dbo].[Order Details] as od on o.OrderID = od.OrderID
group by
	c.CustomerID,
	c.[CompanyName]
order by
	sum(od.[Quantity] * od.[UnitPrice]) desc



--- Identify products that have never been ordered


select
	p.ProductID,
	p.ProductName,
	count(od.[OrderID]) as 'orders'
from
	[dbo].[Products] as p
	left join
	[dbo].[Order Details] as od on p.ProductID = od.ProductID
where
	od.OrderID is null
group by
	p.ProductID,
	p.ProductName
order by
	count(od.[OrderID]) asc



--- Get the monthly sales report for the last year

select
	year(o.[OrderDate]) as 'Year Date',
	datename(month, o.[OrderDate]) as 'Month Date',
	sum(od.[UnitPrice] * od.[Quantity]) as 'Revenue'
from 
	[dbo].[Orders] as o
	inner join
	[dbo].[Order Details] as od on o.OrderID = od.OrderID
where year(o.[OrderDate]) =
			(
			select max(year([OrderDate])) 
			from [dbo].[Orders]
			)
group by
	year(o.[OrderDate]),
	datename(month, o.[OrderDate]),
	month(o.[OrderDate])
order by
	month(o.[OrderDate])




----- calculate the average price for each category. 


select
	c.CategoryName,
	AVG(p.[UnitPrice]) as 'AVG Price'
from
	[dbo].[Products] as p
	inner join
	[dbo].[Categories] as c on p.CategoryID = c.CategoryID
group by
	c.CategoryName
order by
	count(p.[UnitPrice]) desc




----- calculate the Revenue for each category. 


select
	c.CategoryID,
	c.CategoryName,
	sum(od.[UnitPrice] * od.[Quantity]) as 'Revenue'
from 
	[dbo].[Categories] as c
	inner join
	[dbo].[Products] as p on c.CategoryID = p.CategoryID
	inner join 
	[dbo].[Order Details] as od on od.ProductID = p.ProductID
group by
	c.CategoryID,
	c.CategoryName
order by 
	3 desc


--- List the top 10 customers who made the highest total purchases. 
--- Show customer details and total purchase amount.


select
	top 10 c.CompanyName,
	sum(od.[Quantity]) as 'Total Purchases'
from 
	[dbo].[Customers] as c
	inner join 
	[dbo].[Orders] as o on o.CustomerID = c.CustomerID
	inner join
	[dbo].[Order Details] as od on o.OrderID = od.OrderID
group by
	c.CompanyName
order by
	sum(od.[Quantity]) desc




---- Calculate the rank of each product by price within its category. 
---  Show the product name, price, category, and rank. 

select
	c.CategoryName,
	p.ProductName,
	p.[UnitPrice],
	DENSE_RANK() over(partition by c.[CategoryName] order by p.[UnitPrice] desc) as 'Rank'
from 
	[dbo].[Products] as p
	inner join
	[dbo].[Categories] as c on c.CategoryID = p.CategoryID


-- List the employees who have placed the most orders. 
-- Include employee details and order counts. 

select
	e.EmployeeID,
	e.FirstName,
	e.LastName,
	count(o.[OrderID]) as 'Number of orders'
from 
	[dbo].[Employees] as e
	inner join
	[dbo].[Orders] as o on e.EmployeeID = o.EmployeeID
group by
	e.EmployeeID,
	e.FirstName,
	e.LastName
order by
	count(o.[OrderID]) desc


-- Retrieve all products and calculate the average price for each category. 
-- Show the category name, product name, and average price. 

select
	distinct c.CategoryName,
	p.ProductName,
	cast(round(AVG(p.[UnitPrice]), 0) as int) as 'Product average price'
from 
	[dbo].[Products] as p
	inner join
	[dbo].[Categories] as c on p.CategoryID = c.CategoryID
group by
	c.CategoryName,
	p.ProductName
order by 
	c.CategoryName



-- Calculate the rank of each product by price within its category. 
-- Show the product name, price, category, and rank.


select
	c.CategoryName,
	p.ProductName,
	p.UnitPrice,
	DENSE_RANK() over(partition by c.CategoryName order by p.UnitPrice desc) as 'rank'
from 
	[dbo].[Products] as p
	inner join
	[dbo].[Categories] as c on p.CategoryID = c.CategoryID



-- Retrieve the product names and the number of orders they appear in. 
-- Show the most ordered products first.


select 
	p.ProductName,
	count(o.[OrderID]) as 'orders'
from
	[dbo].[Products] as p
	inner join
	[dbo].[Order Details] as od on p.ProductID = od.ProductID
	inner join
	[dbo].[Orders] as o on o.OrderID = od.OrderID
group by
	p.ProductName
order by
	count(od.[OrderID]) desc


---- Find Customers Who Placed More Orders Than the Average

select
	[CustomerID],
	count([OrderID]) as 'orders'
from
	[dbo].[Orders]
group by
	[CustomerID]
having 
	count([OrderID]) >
					(
					 select count([OrderID])*1.0/ count(distinct[CustomerID])
					 from [dbo].[Orders]
					)
order by
	count([OrderID]) asc



-- B


with CountOrders as
(
select
	[CustomerID],
	count([OrderID]) as TotalOrders
from
	[dbo].[Orders]
group by
	[CustomerID]
), 
AvgOrders as
(
select
	avg(TotalOrders) as AvgOrderCount
from	
	CountOrders
)

select
	c.CustomerID,
	co.TotalOrders
from
	CountOrders as co
	inner join 
	AvgOrders as ao on co.TotalOrders > ao.AvgOrderCount
	inner join
	[dbo].[Customers] as c on co.CustomerID = c.CustomerID


--- Find the Most Loyal Customers Based on Order Frequency
--- Identify customers who place orders frequently, 
--- ranking them by the average number of days between their orders.

with cte as 
(
select
	c.CompanyName as customer,
	cast([OrderDate] as date) as Order_Date,
	lead(cast([OrderDate] as date)) over(partition by c.[CompanyName] order by o.[OrderDate] asc) as Next_Order,
	DATEDIFF(day, cast([OrderDate] as date), lead(cast([OrderDate] as date)) over(partition by c.[CompanyName] order by o.[OrderDate] asc)) as days_Between_Orders
from
	[dbo].[Customers] as c
	inner join
	[dbo].[Orders] as o on c.CustomerID = o.CustomerID
),
cte2 as
(
select
	customer,
	days_Between_Orders,
	AVG(days_Between_Orders) over(partition by customer) as 'Avg_Days'
from 
	cte
where
	Next_Order is not null
)
select 
	distinct customer,
	Avg_Days,
	DENSE_RANK() over(order by Avg_Days asc) as 'Rank'
from
	cte2
order by
	Rank



--- Rank Employees Based on Their Sales Performance
--- Rank employees by their total sales revenue, and show their ranking within the company.


with cte as
(
select
	e.EmployeeID,
	e.FirstName,
	e.LastName,
	sum(od.[UnitPrice] * od.[Quantity]) as 'Revenue'
from 
	[dbo].[Employees] as e
	inner join
	[dbo].[Orders] as o on e.EmployeeID = o.EmployeeID
	inner join
	[dbo].[Order Details] as od on o.OrderID = od.OrderID
group by
	e.EmployeeID,
	e.FirstName,
	e.LastName
)
select
	EmployeeID,
	FirstName,
	LastName,
	Revenue,
	DENSE_RANK() over(order by Revenue desc) as 'Rank'
from
	cte




--- Find the Fastest and Slowest Shippers
--- Identify which shipping company is the fastest and slowest 
--- based on the average number of days between order date and shipped date.

with cte as
(
select
	s.CompanyName as 'Company',
	AVG(DATEDIFF(Day, o.OrderDate, o.[ShippedDate])) over(partition by s.CompanyName) as 'AVG_Days'
from 
	[dbo].[Shippers] as s
	inner join
	[dbo].[Orders] as o on s.ShipperID = o.ShipVia
)
select 
	distinct company,
	 AVG_Days,
	dense_rank() over(order by AVG_Days asc) as 'Fastest',
	dense_rank() over(order by AVG_Days desc) as 'Slowest'
from 
	cte



--- Detect Products That Are Frequently Ordered Together
--- Find pairs of products that are often ordered together (in the same order).



select
	top 10 a.ProductID as product_1,
	b.ProductID as product_2,
	COUNT(*) AS TimesOrderedTogether
from
	[dbo].[Order Details] as a
	inner join
	[dbo].[Order Details] as b on a.OrderID = b.OrderID and a.ProductID < b.ProductID
group by
	a.ProductID,
	b.ProductID 
order by
	3 desc

	

---- Find products that sell a high quantity but are priced significantly higher 
--- than the average price in their category. 
---These might be candidates for a price reduction to increase sales.

-- to finish

with cte as
(
select
	c.CategoryName,
	p.ProductName,
	sum(od.[Quantity]) as quantity,
	od.[UnitPrice],
	avg(od.[UnitPrice]) over(partition by c.CategoryName) as AVG_Price,
	od.[UnitPrice] - avg(od.[UnitPrice]) over(partition by c.CategoryName) as Price_Gap,
	(od.[UnitPrice] / avg(od.[UnitPrice]) over(partition by c.CategoryName) *100) as Price_Gap_Percent
from
	[dbo].[Categories] as c
	inner join
	[dbo].[Products] as p on c.CategoryID = p.CategoryID
	inner join
	[dbo].[Order Details] as od on od.ProductID = p.ProductID
group by
	c.CategoryName,
	p.ProductName,
	od.[UnitPrice]
), 
cte2 as
(
select
	CategoryName,
	ProductName,
	[UnitPrice],
	AVG_Price,
	Price_Gap,
	Price_Gap_Percent,
	DENSE_RANK() over(partition by CategoryName order by Price_Gap desc) as Gap_Rank
from
	cte
)
select
	*
from
	cte2
where
	Gap_Rank = 1



---- Find the top 5 months with the highest total sales revenue

select
	top 5 cast(year(o.[OrderDate]) as varchar) + '-' + cast(month(o.[OrderDate]) as varchar) as 'Year-Month',
	sum(od.[UnitPrice] * od.[Quantity]) as Revenue
from 
	[dbo].[Orders] as o
	inner join
	[dbo].[Order Details] as od on o.OrderID = od.OrderID
group by
	o.OrderDate
order by 
	sum(od.[UnitPrice] * od.[Quantity]) desc


--- List suppliers who supply at least 3 different products


select 
	s.CompanyName,
	count(distinct p.[ProductID]) as 'Products'
from
	[dbo].[Suppliers] as s
	inner join
	[dbo].[Products] as p on s.SupplierID = p.SupplierID
group by
	s.CompanyName
having
	count(distinct p.[ProductID]) >= 3
order by
	count(p.[ProductID]) desc


---  Retrieve the customer who has placed the highest number of orders in a single year.


select
	c.[CompanyName] as 'Customer',
	year(o.[OrderDate]) as 'Year',
	count(o.[OrderID]) as 'Amount of Orders'
from
	[dbo].[Customers] as c
	inner join
	[dbo].[Orders] as o on c.CustomerID = o.CustomerID
group by
	c.[CompanyName],
	year(o.[OrderDate])
order by
	count(o.[OrderID]) desc



--- Find the most profitable product (highest total revenue).

select
	p.ProductName,
	sum(od.[Quantity] * od.[UnitPrice]) as 'Revenue'
from
	[dbo].[Products] as p
	inner join
	[dbo].[Order Details] as od on p.ProductID = od.ProductID
group by
	p.ProductName
order by
	sum(od.[Quantity] * od.[UnitPrice]) desc



	